The models of SDMVC are provided in:
https://pan.baidu.com/s/1WqB7rw8dCCTzWCOatzUaKQ 
pass code：1260 
The pre-trained autoencoders are:  ae_weights.h5
The fine-turned model of SDMVC is : model_final.h5